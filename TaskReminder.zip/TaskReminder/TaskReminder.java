import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

class Task {
    private String title;
    private LocalDate dueDate;

    public Task(String title, String dueDate) {
        this.title = title;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.dueDate = LocalDate.parse(dueDate, formatter);
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public boolean isOverdue() {
        return LocalDate.now().isAfter(dueDate);
    }

    public void setTitle(String newTitle) {
        this.title = newTitle;
    }

    public void setDueDate(String newDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.dueDate = LocalDate.parse(newDate, formatter);
    }

    @Override
    public String toString() {
        return title + " | Due: " + dueDate + (isOverdue() ? " (Overdue!)" : "");
    }
}

public class TaskReminder {
    private static List<Task> tasks = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n=== TASK REMINDER APPLICATION ===");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Edit Task");
            System.out.println("4. Delete Task");
            System.out.println("5. View Overdue Tasks");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1 -> addTask();
                case 2 -> viewTasks();
                case 3 -> editTask();
                case 4 -> deleteTask();
                case 5 -> viewOverdueTasks();
                case 0 -> System.out.println("Exiting... Goodbye!");
                default -> System.out.println("Invalid choice!");
            }
        } while (choice != 0);
    }

    private static void addTask() {
        System.out.print("Enter task title: ");
        String title = sc.nextLine();
        System.out.print("Enter due date (yyyy-MM-dd): ");
        String date = sc.nextLine();

        tasks.add(new Task(title, date));
        System.out.println("✅ Task added successfully!");
    }

    private static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks added yet.");
            return;
        }
        System.out.println("\n--- All Tasks ---");
        for (int i = 0; i < tasks.size(); i++) {
            System.out.println((i + 1) + ". " + tasks.get(i));
        }
    }

    private static void editTask() {
        viewTasks();
        if (tasks.isEmpty()) return;

        System.out.print("Enter task number to edit: ");
        int index = sc.nextInt() - 1;
        sc.nextLine();

        if (index >= 0 && index < tasks.size()) {
            Task t = tasks.get(index);
            System.out.print("Enter new title (leave blank to keep same): ");
            String newTitle = sc.nextLine();
            System.out.print("Enter new due date (yyyy-MM-dd, leave blank to keep same): ");
            String newDate = sc.nextLine();

            if (!newTitle.isEmpty()) t.setTitle(newTitle);
            if (!newDate.isEmpty()) t.setDueDate(newDate);
            System.out.println("✅ Task updated!");
        } else {
            System.out.println("Invalid task number!");
        }
    }

    private static void deleteTask() {
        viewTasks();
        if (tasks.isEmpty()) return;

        System.out.print("Enter task number to delete: ");
        int index = sc.nextInt() - 1;
        sc.nextLine();

        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
            System.out.println("🗑️ Task deleted successfully!");
        } else {
            System.out.println("Invalid task number!");
        }
    }

    private static void viewOverdueTasks() {
        boolean found = false;
        System.out.println("\n--- Overdue Tasks ---");
        for (Task t : tasks) {
            if (t.isOverdue()) {
                System.out.println(t);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No overdue tasks!");
        }
    }
}
