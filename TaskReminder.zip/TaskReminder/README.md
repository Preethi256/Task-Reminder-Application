# 🗓️ Task Reminder Application (Java)

A simple Java console-based task reminder system.

## Features
- Add, edit, delete tasks  
- Set deadlines (yyyy-MM-dd format)  
- Display overdue tasks automatically  
- Console-based & easy to run

## Run Instructions
1. Compile:
   ```bash
   javac TaskReminder.java
   ```
2. Run:
   ```bash
   java TaskReminder
   ```
3. Follow the menu prompts.

## Example
```
=== TASK REMINDER APPLICATION ===
1. Add Task
2. View Tasks
3. Edit Task
4. Delete Task
5. View Overdue Tasks
0. Exit
```
